const LIBRARY_ID = '754178';
const catalog = [
  { title: 'The Grave', image: 'thegrave-test-cover.jpeg', video: '5800724a-7318-4cba-bb47-625cad9bb4ef', genre: 'Skräck · Thriller', year: '1989', original: 'The Grave', director: 'Elias Vinter', cast: 'Lena Bratt, Jonas Ek, Birgitta Holm', runtime: '101 min', rating: '15 år', audio: 'Hi-Fi Stereo', price: '39 kr', tagline: 'Vissa gravar ska aldrig öppnas.', summary: 'En nattvakt hittar en nygrävd grav bakom den gamla kyrkogården. När han börjar undersöka saken väcks något som borde ha förblivit begravt.' },
  { title: 'Toy Store', image: 'toystore-cover.jpeg', video: 'd0174d3c-0882-4bba-b725-fa3e9b863f06', genre: 'Skräck · Mysterium', year: '1988', original: 'Toy Store', director: 'Karin Ståhl', cast: 'Mikael Roos, Eva Lund, Per Åkesson', runtime: '96 min', rating: '15 år', audio: 'Hi-Fi Stereo', price: '35 kr', tagline: 'Lekarna tar aldrig slut.', summary: 'I en leksaksbutik som bara öppnar efter midnatt börjar föremålen röra sig på egen hand. En desperat natt blir snart en kamp mot butikens mörka hemlighet.' },
  { title: "Don't Look Twice", image: 'dont-look-twice-cover.jpeg', video: 'c06c6a15-c907-4020-84de-466055248256', genre: 'Skräck · Thriller', year: '1990', original: "Don't Look Twice", director: 'Maja Lennart', cast: 'Anna Berg, Henrik Dahl, Sofia Nordin', runtime: '92 min', rating: '15 år', audio: 'PAL · Stereo', price: '40 kr', tagline: 'Vänd dig aldrig om.', summary: 'Efter ett mystiskt möte på en ödslig väg börjar varje spegel visa något som inte borde finnas där. Ju mer hon försöker förstå, desto närmare kommer det.' }
  ,{ title: 'Clown Prank', image: 'clown-prank.jpeg', video: '14e08eb0-a0ef-45ae-83a4-c6c2b08101c9', genre: 'Skräckkomedi', year: '1991', original: 'Clown Prank', director: 'Arthur P. Sterling', cast: 'Arthur P. Sterling, Alwyn Bagait, Gary Sterling', runtime: '93 min', rating: '15 år', audio: 'Hi-Fi Stereo', price: '35 kr', tagline: 'Han är inte här för att mörda dig... bara för att jävlas.', summary: 'En förrymd cirkusclown terroriserar en stillsam förort med bisarra practical jokes i en absurd och psykologiskt påfrestande skräckkomedi.' }
];
const movies = Array.from({ length: 20 }, (_, i) => catalog[i % catalog.length]);
const shelf = document.querySelector('#shelf');
const dialog = document.querySelector('#movie-dialog');
const trailerMount = document.querySelector('#trailer-mount');
const trailerPanel = document.querySelector('.trailer');
const fields = { genre:'#detail-genre', title:'#detail-title', year:'#detail-year', summary:'#detail-summary', tagline:'#detail-tagline', original:'#detail-original', director:'#detail-director', cast:'#detail-cast', runtime:'#detail-runtime', rating:'#detail-rating', audio:'#detail-audio', price:'#rent-price' };
let current;
let activeFrame = null;
const setText = (key, value) => { const el = document.querySelector(fields[key]); if (el) el.textContent = value; };

// Skicka kommandon direkt enligt Player.js-protokollet som Bunny-spelaren använder.
function sendPlayerCommand(method, value) {
  if (!activeFrame?.contentWindow) return;
  const message = { context: 'player.js', version: '0.0.11', method };
  if (value !== undefined) message.value = value;
  activeFrame.contentWindow.postMessage(JSON.stringify(message), '*');
  activeFrame.contentWindow.postMessage(message, '*');
}

function loadTrailer(movie) {
  trailerPanel.classList.remove('is-playing');
  trailerMount.replaceChildren();
  const iframe = document.createElement('iframe');
  iframe.id = 'trailer-player';
  iframe.title = `${movie.title} trailer`;
  iframe.allow = 'autoplay; fullscreen; picture-in-picture';
  iframe.allowFullscreen = true;
  iframe.loading = 'eager';
  iframe.referrerPolicy = 'strict-origin-when-cross-origin';
  activeFrame = iframe;

  iframe.addEventListener('load', () => {
    sendPlayerCommand('setCurrentTime', 0);
    sendPlayerCommand('setLoop', true);
    sendPlayerCommand('setVolume', 15);
    sendPlayerCommand('unmute');
    sendPlayerCommand('play');
    try {
      const player = new playerjs.Player(iframe);
      player.on('ready', () => { player.setCurrentTime(0); player.setVolume(15); player.unmute(); player.play(); });
    } catch (_) { /* autoplay och postMessage används som fallback */ }
  }, { once: true });

  iframe.src = `https://iframe.mediadelivery.net/embed/${LIBRARY_ID}/${movie.video}?autoplay=true&muted=true&loop=true&preload=true&playsinline=true&start=0&rememberPosition=false`;
  trailerMount.appendChild(iframe);
  window.setTimeout(() => trailerPanel.classList.add('is-playing'), 4000);
}

window.addEventListener('message', event => {
  if (!activeFrame || event.source !== activeFrame.contentWindow) return;
  let data = event.data;
  try { if (typeof data === 'string') data = JSON.parse(data); } catch (_) { return; }
  if (data?.event === 'play' || data?.event === 'playing' || data?.event === 'timeupdate') trailerPanel.classList.add('is-playing');
});
function openFilm(index) {
  current = movies[index];
  const cover = document.querySelector('#detail-cover');
  cover.style.backgroundImage = `url("assets/${current.image}")`;
  Object.entries(current).forEach(([key, value]) => { if (key in fields) setText(key, value); });
  dialog.showModal();
  loadTrailer(current);
}
function closeFilm() {
  if (dialog.open) dialog.close();
  if (activeFrame) activeFrame.src = 'about:blank';
  trailerMount.replaceChildren();
  trailerPanel.classList.remove('is-playing');
  activeFrame = null;
}

// En webbläsare kan återställa ett öppet dialogelement efter omladdning.
// Börja därför alltid från hyllan och skapa en helt ny spelare vid nästa val.
dialog.removeAttribute('open');
trailerMount.replaceChildren();
for (let row = 0; row < 4; row++) {
  const rowEl = document.createElement('div'); rowEl.className = 'shelf-row';
  for (let col = 0; col < 5; col++) {
    const index = row * 5 + col, movie = movies[index];
    const cover = document.createElement('button');
    cover.className = 'vhs'; cover.type = 'button'; cover.dataset.index = index; cover.setAttribute('aria-label', movie.title);
    cover.style.backgroundImage = `url("assets/${movie.image}")`;
    rowEl.appendChild(cover);
  }
  shelf.appendChild(rowEl);
}
shelf.addEventListener('click', e => { const cover = e.target.closest('.vhs'); if (cover) openFilm(Number(cover.dataset.index)); });
document.querySelector('.close').addEventListener('click', closeFilm);
dialog.addEventListener('click', e => { if (e.target === dialog) closeFilm(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && dialog.open) closeFilm(); });
